import * as React from "react";
import { Link } from "react-router-dom";
import Switch from "./ui/switch.jsx";
import Button from "./ui/button.jsx";
import { ThemeContext } from "../context/ThemeContext.jsx";

export default class SiteHeader extends React.Component {
	static contextType = ThemeContext;

	render() {
		const {
			navItems = null,
			onNavClick = null,
		} = this.props;

		const { isDark, toggle } = this.context;

		return (
			<header className="border-b border-border bg-surface1">
				<div className="container-page flex items-center justify-between py-3 gap-4">

					{/* Left: Branding */}
					<div className="flex items-center gap-4 min-w-0">
						<Link to="/" className="leading-tight shrink-0">
							<div className="text-sm text-muted">University of Cambridge</div>
							<div className="font-semibold tracking-[var(--ls-heading)]">
								Language Centre
							</div>
						</Link>

						{/* Compact horizontal nav */}
						{Array.isArray(navItems) && navItems.length ? (
							<nav className="hidden md:flex items-center gap-1 overflow-x-auto whitespace-nowrap">
								{navItems.map((item) => (
									<Button
										key={item.id}
										variant="ghost"
										size="sm"
										onClick={(e) =>
											onNavClick ? onNavClick(e, item.id) : null
										}
									>
										{item.label}
									</Button>
								))}
							</nav>
						) : null}
					</div>

					{/* Right: Theme */}
					<div className="flex items-center gap-2 shrink-0">
						<span className="text-sm text-muted hidden sm:inline">
							{isDark ? "Dark" : "Light"}
						</span>
						<Switch
							checked={isDark}
							onCheckedChange={toggle}
							aria-label="Toggle theme"
						/>
					</div>
				</div>

				{/* Mobile nav (second row only on small screens) */}
				{Array.isArray(navItems) && navItems.length ? (
					<div className="md:hidden border-t border-border">
						<div className="container-page py-2">
							<div className="flex items-center gap-1 overflow-x-auto whitespace-nowrap">
								{navItems.map((item) => (
									<Button
										key={item.id}
										variant="ghost"
										size="sm"
										onClick={(e) =>
											onNavClick ? onNavClick(e, item.id) : null
										}
									>
										{item.label}
									</Button>
								))}
							</div>
						</div>
					</div>
				) : null}
			</header>
		);
	}
}
