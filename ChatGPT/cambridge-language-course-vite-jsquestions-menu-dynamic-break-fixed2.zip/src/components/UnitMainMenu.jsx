import * as React from "react";
import { Link } from "react-router-dom";
import { Menu, X, Moon, Sun } from "lucide-react";
import "./MainMenu.scss";
import Button from "./ui/button.jsx";
import { ThemeContext } from "../context/ThemeContext.jsx";
import { handleSpecialLinkClick } from "../lib/scroll.js";

export class UnitMainMenu extends React.Component {
	static contextType = ThemeContext;

	constructor(props) {
		super(props);

		this.state = {
			menuHighlight: null,
			mobileOpen: false,
			compactMode: false,
		};

		this.menuFlexRef = React.createRef();
		this.menuRightRef = React.createRef();
		this.menuActionsRef = React.createRef();
	}

	componentDidMount() {
		this.updateHighlight();
		this.updateCompactMode();

		this.scrollHandler = () => {
			if (this._scrollTicking) return;
			this._scrollTicking = true;
			setTimeout(() => {
				this.updateHighlight();
				this._scrollTicking = false;
			}, 150);
		};

		this.resizeHandler = () => {
			this.updateCompactMode();

			// If we resized back to desktop-fit, close mobile menu
			if (!this.state.compactMode && this.state.mobileOpen) {
				this.setState({ mobileOpen: false });
			}

			this.updateHighlight();
		};

		document.addEventListener("scroll", this.scrollHandler, { passive: true });
		window.addEventListener("resize", this.resizeHandler);

		// Observe header size changes (fonts, zoom, dynamic items)
		if (window.ResizeObserver) {
			this.ro = new ResizeObserver(() => this.updateCompactMode());
			const el = this.menuFlexRef.current;
			if (el) this.ro.observe(el);
		}
	}

	componentWillUnmount() {
		document.removeEventListener("scroll", this.scrollHandler);
		window.removeEventListener("resize", this.resizeHandler);
		if (this.ro) this.ro.disconnect();
	}

updateCompactMode() {
	const menuFlex = this.menuFlexRef.current;
	const menuRight = this.menuRightRef.current;
	if (!menuFlex || !menuRight) return;

	// Trigger "compact" (burger) when the header would overflow horizontally.
	// This is robust to variable item count/labels, zoom, fonts, etc.
	const safety = 2; // px wiggle room

	const headerOverflow = menuFlex.scrollWidth > (menuFlex.clientWidth + safety);
	const navOverflow = menuRight.scrollWidth > (menuRight.clientWidth + safety);

	const shouldCompact = headerOverflow || navOverflow;

	if (shouldCompact !== this.state.compactMode) {
		this.setState({ compactMode: shouldCompact });
	}
}

	updateHighlight() {
		const { navItems } = this.props;
		const mainMenu = document.getElementById("mainMenu");
		if (!mainMenu || !Array.isArray(navItems) || !navItems.length) return;

		const mainMenuBottom = mainMenu.getBoundingClientRect().bottom;
		const viewportHeight = window.innerHeight || document.documentElement.clientHeight;

		const candidates = [];

		for (const item of navItems) {
			const target = document.getElementById(item.anchorId);
			if (!target) continue;

			const rect = target.getBoundingClientRect();
			if (rect.top >= mainMenuBottom && rect.top < viewportHeight) {
				candidates.push({ key: item.key, top: rect.top });
			}
		}

		if (candidates.length) {
			candidates.sort((a, b) => a.top - b.top);
			const best = candidates[0].key;
			if (this.state.menuHighlight !== best) {
				this.setState({ menuHighlight: best });
			}
		}
	}

	toggleMobileMenu = () => {
		this.setState((prev) => ({ mobileOpen: !prev.mobileOpen }));
	};

	handleNavClick = (e) => {
		handleSpecialLinkClick(e);
		if (this.state.mobileOpen) this.setState({ mobileOpen: false });
	};

	render() {
		const { navItems } = this.props;
		const { mobileOpen, menuHighlight, compactMode } = this.state;
		const { isDark, toggle } = this.context;

		const hasNav = Array.isArray(navItems) && navItems.length;

		const topMenu = [];
		const mobileMenuItems = [];

		if (hasNav) {
			for (const item of navItems) {
				const highlight = menuHighlight === item.key;
				const href = `#${item.anchorId}`;

				topMenu.push(
					<li
						className={highlight ? "highlight" : ""}
						id={item.key}
						key={item.key}
					>
						<a className="special-anchor nav nav-link" href={href} onClick={this.handleNavClick}>
							{item.label}
						</a>
					</li>
				);

				mobileMenuItems.push(
					<li key={`mobile-${item.key}`} className={highlight ? "highlight" : ""}>
						<a
							href={href}
							className="nav-link nav-link-mobile nav special-anchor"
							onClick={this.handleNavClick}
						>
							{item.label}
						</a>
					</li>
				);
			}
		}

		const themeIcon = isDark ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />;
		const themeTitle = isDark ? "Switch to light mode" : "Switch to dark mode";

		return (
			<header className={`main-menu ${compactMode ? "is-compact" : ""}`} id="mainMenu">
				<div className="menu-root w-100">
					<div className="menu-flex" ref={this.menuFlexRef}>

						{/* LEFT — Title / brand */}
						<div className="menu-left">
							<Link
								to="/"
								className="special-anchor nav nav-title"
								onClick={() => { if (mobileOpen) this.setState({ mobileOpen: false }); }}
							>
								<span>University of Cambridge</span>
								<span className="nav-title-sep" aria-hidden="true">&nbsp;</span>
								<span>Language Centre</span>
							</Link>
						</div>

						{/* DESKTOP — Right-hand nav (only when it fits) */}
						{hasNav ? (
							<ul className="menu-right" ref={this.menuRightRef}>
								{topMenu}
							</ul>
						) : (
							<div className="menu-right" ref={this.menuRightRef} />
						)}

						{/* RIGHT — Actions: burger (inboard) + theme toggle (rightmost) */}
						<div className="menu-actions" ref={this.menuActionsRef}>
							{hasNav ? (
								<button
									type="button"
									className={`menu-toggle-button ${mobileOpen ? "is-open" : ""}`}
									aria-label="Toggle navigation menu"
									aria-expanded={mobileOpen}
									onClick={this.toggleMobileMenu}
								>
									{!mobileOpen ? (
										<Menu aria-hidden="true" />
									) : (
										<X aria-hidden="true" />
									)}
								</button>
							) : null}

							<Button
								className="size-9"
								variant="ghost"
								size="sm"
								onClick={toggle}
								title={themeTitle}
								aria-label={themeTitle}
							>
								{themeIcon}
							</Button>
						</div>
					</div>
				</div>

				{/* MOBILE DROPDOWN NAV (used whenever compact mode is active) */}
				{hasNav ? (
					<nav
						className={`mobile-menu ${(mobileOpen && compactMode) ? "open" : ""}`}
						aria-label="Unit navigation mobile"
					>
						<ul className="mobile-menu-list">
							{mobileMenuItems}
						</ul>
					</nav>
				) : null}
			</header>
		);
	}
}
