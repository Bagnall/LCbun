import React from "react";
import { Link } from "react-router-dom";
import useTheme from "../hooks/useTheme.js";
import SiteHeader from "../components/SiteHeader.jsx";
import SiteFooter from "../components/SiteFooter.jsx";
import Button from "../components/ui/button.jsx";

export default function CreditsPage() {
  const { isDark, toggle } = useTheme();
  return (
	<div className="min-h-screen flex flex-col bg-bg text-text">
	  <SiteHeader onToggleTheme={toggle} isDark={isDark} />
	  <main className="flex-1">
		<section className="py-10">
		  <div className="container-page">
			<h1 className="text-[var(--fs-h1)] tracking-[var(--ls-heading)] font-semibold">Credits</h1>
			<p className="mt-3 text-muted max-w-measure">
			  Placeholder credits page. Add acknowledgements, authors, and licences here.
			</p>
			<div className="mt-6">
			  <Button asChild variant="ghost">
				<Link to="/">← Back to course</Link>
			  </Button>
			</div>
		  </div>
		</section>
	  </main>
	  <SiteFooter withLinks />
	</div>
  );
}
