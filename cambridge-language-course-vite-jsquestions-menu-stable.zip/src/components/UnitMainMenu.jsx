import * as React from "react";
import { Link } from "react-router-dom";
import { Menu, X, Moon, Sun } from "lucide-react";
import "./MainMenu.scss";
import Button from "./ui/button.jsx";
import { ThemeContext } from "../context/ThemeContext.jsx";
import { handleSpecialLinkClick } from "../lib/scroll.js";

export class UnitMainMenu extends React.Component {
	static contextType = ThemeContext;

	constructor(props) {
		super(props);

		this.state = {
			menuHighlight: null,
			mobileOpen: false,
			compactMode: false,
		};

		this.menuFlexRef = React.createRef();
		this.menuLeftRef = React.createRef();
		this.menuActionsRef = React.createRef();
		this.menuMeasureRef = React.createRef();

		this._scrollTicking = false;
		this._rafPending = false;
	}

	componentDidMount() {
		this.updateHighlight();
		this.updateCompactMode();

		this.scrollHandler = () => {
			if (this._scrollTicking) return;
			this._scrollTicking = true;

			setTimeout(() => {
				this.updateHighlight();
				this._scrollTicking = false;
			}, 150);
		};

		this.resizeHandler = () => {
			this.updateCompactMode();
			this.updateHighlight();
		};

		document.addEventListener("scroll", this.scrollHandler, { passive: true });
		window.addEventListener("resize", this.resizeHandler);

		if (window.ResizeObserver) {
			this.ro = new ResizeObserver(() => this.updateCompactMode());
			if (this.menuFlexRef.current) this.ro.observe(this.menuFlexRef.current);
			if (this.menuMeasureRef.current) this.ro.observe(this.menuMeasureRef.current);
		}
	}

	componentWillUnmount() {
		document.removeEventListener("scroll", this.scrollHandler);
		window.removeEventListener("resize", this.resizeHandler);
		if (this.ro) this.ro.disconnect();
		if (this._rafPending) cancelAnimationFrame(this._rafPending);
	}

	updateCompactMode() {
		// Debounce to animation frame to avoid flicker from rapid measurements
		if (this._rafPending) return;

		this._rafPending = requestAnimationFrame(() => {
			this._rafPending = false;

			const menuFlex = this.menuFlexRef.current;
			const menuLeft = this.menuLeftRef.current;
			const menuActions = this.menuActionsRef.current;
			const menuMeasure = this.menuMeasureRef.current;

			if (!menuFlex || !menuLeft || !menuActions || !menuMeasure) return;

			const availableWidth = menuFlex.clientWidth;

			const leftWidth = menuLeft.getBoundingClientRect().width;
			const actionsWidth = menuActions.getBoundingClientRect().width;

			// Measure the FULL natural width of the nav items (independent of whether nav is visible)
			const navWidth = menuMeasure.scrollWidth;

			// Buffer so we switch before clipping begins
			const enterGap = 40;
			const exitGap = 16;

			const used = leftWidth + actionsWidth + navWidth;

			const shouldEnterCompact = used > (availableWidth - enterGap);
			const shouldExitCompact = used < (availableWidth - exitGap);

			let nextCompact = this.state.compactMode;

			if (!this.state.compactMode && shouldEnterCompact) nextCompact = true;
			if (this.state.compactMode && shouldExitCompact) nextCompact = false;

			if (nextCompact !== this.state.compactMode) {
				// If leaving compact, also close mobile menu
				this.setState({
					compactMode: nextCompact,
					mobileOpen: nextCompact ? this.state.mobileOpen : false,
				});
			}
		});
	}

	updateHighlight() {
		const { navItems } = this.props;
		const mainMenu = document.getElementById("mainMenu");
		if (!mainMenu || !Array.isArray(navItems) || !navItems.length) return;

		const mainMenuBottom = mainMenu.getBoundingClientRect().bottom;
		const viewportHeight = window.innerHeight || document.documentElement.clientHeight;

		const candidates = [];

		for (const item of navItems) {
			const target = document.getElementById(item.anchorId);
			if (!target) continue;

			const rect = target.getBoundingClientRect();
			if (rect.top >= mainMenuBottom && rect.top < viewportHeight) {
				candidates.push({ key: item.key, top: rect.top });
			}
		}

		if (candidates.length) {
			candidates.sort((a, b) => a.top - b.top);
			const best = candidates[0].key;
			if (this.state.menuHighlight !== best) {
				this.setState({ menuHighlight: best });
			}
		}
	}

	toggleMobileMenu = () => {
		this.setState((prev) => ({ mobileOpen: !prev.mobileOpen }));
	};

	handleNavClick = (e) => {
		handleSpecialLinkClick(e);
		if (this.state.mobileOpen) this.setState({ mobileOpen: false });
	};

	render() {
		const { navItems } = this.props;
		const { mobileOpen, menuHighlight, compactMode } = this.state;
		const { isDark, toggle } = this.context;

		const hasNav = Array.isArray(navItems) && navItems.length;

		const topMenu = [];
		const mobileMenuItems = [];

		if (hasNav) {
			for (const item of navItems) {
				const highlight = menuHighlight === item.key;
				const href = `#${item.anchorId}`;

				topMenu.push(
					<li className={highlight ? "highlight" : ""} id={item.key} key={item.key}>
						<a className="special-anchor nav nav-link" href={href} onClick={this.handleNavClick}>
							{item.label}
						</a>
					</li>
				);

				mobileMenuItems.push(
					<li key={`mobile-${item.key}`} className={highlight ? "highlight" : ""}>
						<a href={href} className="nav-link nav-link-mobile nav special-anchor" onClick={this.handleNavClick}>
							{item.label}
						</a>
					</li>
				);
			}
		}

		const themeIcon = isDark ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />;
		const themeTitle = isDark ? "Switch to light mode" : "Switch to dark mode";

		return (
			<header className={`main-menu ${compactMode ? "is-compact" : ""}`} id="mainMenu">
				<div className="menu-root w-100">
					<div className="menu-flex" ref={this.menuFlexRef}>
						<div className="menu-left" ref={this.menuLeftRef}>
							<Link to="/" className="nav-title-link" onClick={() => { if (mobileOpen) this.setState({ mobileOpen: false }); }}>
								<div className="nav-title-small">University of Cambridge</div>
								<div className="nav-title-large">Language Centre</div>
							</Link>
						</div>

						{/* Visible desktop nav */}
						{hasNav ? (
							<ul className="menu-right">
								{topMenu}
							</ul>
						) : (
							<div className="menu-right" />
						)}

						{/* Measure-only nav (off-screen) */}
						{hasNav ? (
							<ul className="menu-right-measure" ref={this.menuMeasureRef} aria-hidden="true">
								{topMenu}
							</ul>
						) : null}

						{/* Actions: burger inboard, theme rightmost */}
						<div className="menu-actions" ref={this.menuActionsRef}>
							{hasNav ? (
								<button
									type="button"
									className={`menu-toggle-button ${mobileOpen ? "is-open" : ""}`}
									aria-label="Toggle navigation menu"
									aria-expanded={mobileOpen}
									onClick={this.toggleMobileMenu}
								>
									{!mobileOpen ? <Menu aria-hidden="true" /> : <X aria-hidden="true" />}
								</button>
							) : null}

							<Button className="size-9" variant="ghost" size="sm" onClick={toggle} title={themeTitle} aria-label={themeTitle}>
								{themeIcon}
							</Button>
						</div>
					</div>
				</div>

				{hasNav ? (
					<nav className={`mobile-menu ${(mobileOpen && compactMode) ? "open" : ""}`} aria-label="Unit navigation mobile">
						<ul className="mobile-menu-list">
							{mobileMenuItems}
						</ul>
					</nav>
				) : null}
			</header>
		);
	}
}
